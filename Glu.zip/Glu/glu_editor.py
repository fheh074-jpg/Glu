import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
import subprocess, threading, os, sys, traceback
from PIL import Image

# Crash popup
def crash_popup(type_, value, tb):
    import tkinter.messagebox as msg
    err = "".join(traceback.format_exception(type_, value, tb))
    msg.showerror("Glu Editor Crash", err)
sys.excepthook = crash_popup

os.chdir(os.path.dirname(os.path.abspath(__file__)))

GLU_COMMANDS = [
    "createObject()",
    "moveNorth()",
    "moveSouth()",
    "moveEast()",
    "moveWest()",
    "pmovement()",
    "stepSize = "
]

TUTORIAL_TEXT = """
Welcome to Glu IDE 👋

Commands:
createObject("name", x=1, y=2, texture="file.png")
moveNorth("name"), moveSouth("name"), moveEast("name"), moveWest("name")
pmovement(wasd)
stepSize = 4

Tips:
- Textures go in textures/
- Press TAB to accept autocomplete
- Press Run ▶ to launch game
"""

class GluEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("Glu IDE")
        self.root.geometry("1300x800")
        self.root.configure(bg="#2b2b2b")
        self.current_file = None

        self.ensure_textures()
        self.build_ui()
        self.bind_events()

    # Create textures folder and demo textures
    def ensure_textures(self):
        if not os.path.exists("textures"):
            os.makedirs("textures")
        for name,color in [("snake.png","green"),("ball.png","red"),("paddle.png","blue")]:
            path = os.path.join("textures",name)
            if not os.path.exists(path):
                img = Image.new("RGB",(32,32),color=color)
                img.save(path)

    # ---------- UI ----------
    def build_ui(self):
        self.top = tk.Frame(self.root,bg="#323232",height=45)
        self.top.pack(fill="x")

        tk.Button(self.top,text="Open",command=self.open_file,bg="#3c3c3c",fg="white").pack(side="left",padx=5,pady=5)
        tk.Button(self.top,text="Save",command=self.save_file,bg="#3c3c3c",fg="white").pack(side="left",padx=5,pady=5)
        tk.Button(self.top,text="Run ▶",command=self.run_glu,bg="#4CAF50",fg="white").pack(side="right",padx=5,pady=5)
        tk.Button(self.top,text="Demos",command=self.show_demos,bg="#3C3C3C",fg="white").pack(side="right",padx=5,pady=5)

        main = tk.Frame(self.root,bg="#2b2b2b")
        main.pack(fill="both",expand=True)

        self.files_panel = tk.Listbox(main,width=30,bg="#252526",fg="white",selectbackground="#3c3c3c")
        self.files_panel.pack(side="left",fill="y")
        self.refresh_files()

        editor_frame = tk.Frame(main,bg="#1e1e1e")
        editor_frame.pack(side="left",fill="both",expand=True)

        self.lines = tk.Text(editor_frame,width=4,bg="#2b2b2b",fg="#888",
                             state="disabled",font=("Consolas",12))
        self.lines.pack(side="left",fill="y")

        self.text = tk.Text(editor_frame,font=("Consolas",14),bg="#1e1e1e",fg="white",
                            insertbackground="white",undo=True,wrap="none",selectbackground="#555555")
        self.text.pack(side="left",fill="both",expand=True)
        self.text.tag_configure("current_line",background="#2a2a2a")

        self.tutorial = scrolledtext.ScrolledText(main,width=35,bg="#252526",fg="lightgreen",
                                                  font=("Consolas",12))
        self.tutorial.insert("1.0",TUTORIAL_TEXT)
        self.tutorial.config(state="disabled")
        self.tutorial.pack(side="right",fill="y")

        self.console = scrolledtext.ScrolledText(self.root,height=8,bg="#111111",fg="lightgreen",state="disabled")
        self.console.pack(fill="x")

        self.popup = tk.Listbox(self.root,bg="#333",fg="white",font=("Consolas",12),height=6)
        self.popup.place_forget()

        self.status = tk.Label(self.root,text="Ln 1, Col 1",bg="#323232",fg="white",anchor="w")
        self.status.pack(fill="x")

    def bind_events(self):
        self.text.bind("<KeyRelease>",self.on_type)
        self.text.bind("<Tab>",self.apply_autocomplete)
        self.text.bind("<ButtonRelease>",self.update_status)
        self.text.bind("<Motion>",self.highlight_current_line)
        self.files_panel.bind("<<ListboxSelect>>",self.load_selected_file)

    # ---------- Autocomplete ----------
    def on_type(self,event=None):
        self.update_lines()
        self.update_status()
        self.highlight_current_line()
        cursor = self.text.index(tk.INSERT)
        line = self.text.get(cursor+" linestart",cursor).strip()
        word = line.split("(")[0]
        matches = [c for c in GLU_COMMANDS if c.startswith(word)]
        if matches and word:
            bbox = self.text.bbox(tk.INSERT)
            if bbox:
                x,y,_,_ = bbox
                self.popup.place(x=x+80,y=y+80)
                self.popup.delete(0,tk.END)
                for m in matches: self.popup.insert(tk.END,m)
        else:
            self.popup.place_forget()

    def apply_autocomplete(self,event):
        if self.popup.winfo_ismapped():
            selection = self.popup.get(0)
            cursor = self.text.index(tk.INSERT)
            line_start = self.text.index(cursor+" linestart")
            self.text.delete(line_start,cursor)
            self.text.insert(line_start,selection)
            self.popup.place_forget()
            return "break"

    def highlight_current_line(self,event=None):
        self.text.tag_remove("current_line","1.0","end")
        self.text.tag_add("current_line","insert linestart","insert lineend+1c")

    def update_lines(self):
        count = int(self.text.index('end-1c').split('.')[0])
        self.lines.config(state="normal")
        self.lines.delete("1.0",tk.END)
        for i in range(1,count+1): self.lines.insert(tk.END,f"{i}\n")
        self.lines.config(state="disabled")

    def update_status(self,event=None):
        row,col = self.text.index(tk.INSERT).split(".")
        self.status.config(text=f"Ln {row}, Col {col}")

    # ---------- Files ----------
    def refresh_files(self):
        self.files_panel.delete(0,tk.END)
        for f in os.listdir("."):
            if f.endswith(".glu"): self.files_panel.insert(tk.END,f)

    def load_selected_file(self,event):
        sel = self.files_panel.curselection()
        if sel:
            filename = self.files_panel.get(sel[0])
            self.open_file(filename)

    def open_file(self,file=None):
        if not file:
            file = filedialog.askopenfilename(filetypes=[("Glu files","*.glu")])
        if file:
            self.current_file = file
            with open(file) as f:
                self.text.delete("1.0",tk.END)
                self.text.insert("1.0",f.read())
            self.update_lines()

    def save_file(self):
        if not self.current_file:
            file = filedialog.asksaveasfilename(defaultextension=".glu")
            if not file: return
            self.current_file = file
        with open(self.current_file,"w") as f:
            f.write(self.text.get("1.0",tk.END))

    # ---------- Run ----------
    def run_glu(self):
        code = self.text.get("1.0",tk.END)
        if not code.strip():
            messagebox.showinfo("Info","Editor is empty.")
            return
        runner = os.path.join(os.path.dirname(__file__),"glu_runner.py")
        def run():
            self.console.config(state="normal")
            self.console.insert(tk.END,"Running demo...\n")
            self.console.see(tk.END)
            import tempfile
            try:
                with tempfile.NamedTemporaryFile(mode="w+",suffix=".glu",delete=False) as tmp:
                    tmp.write(code)
                    tmp_path = tmp.name
                subprocess.run(["python",runner,tmp_path])
            except Exception as e:
                self.console.insert(tk.END,f"Error: {e}\n")
            self.console.insert(tk.END,"Execution finished.\n")
            self.console.see(tk.END)
            self.console.config(state="disabled")
        threading.Thread(target=run).start()

    # ---------- Demos ----------
    def show_demos(self):
        demos = {
            "Snake": '''-- Snake demo
createObject("snake", x=5, y=5, texture="snake.png")
''',
            "Pong": '''-- Pong demo
createObject("ball", x=10, y=10, texture="ball.png")
createObject("paddle1", x=1, y=5, texture="paddle.png")
createObject("paddle2", x=18, y=5, texture="paddle.png")
''',
            "Bouncing Ball": '''-- Bouncing Ball demo
createObject("ball", x=10, y=5, texture="ball.png")
stepSize = 1
''',
            "Moving Square": '''-- Simple movement demo
createObject("square", x=5, y=5, texture="ball.png")
''',
            "Chaser": '''-- Chaser demo
createObject("player", x=5, y=5, texture="snake.png")
createObject("chaser", x=15, y=10, texture="ball.png")
'''
        }

        popup = tk.Toplevel(self.root)
        popup.title("Select a Demo")
        popup.geometry("300x200")
        popup.configure(bg="#2b2b2b")
        tk.Label(popup,text="Select a demo to load:",bg="#2b2b2b",fg="white").pack(pady=10)
        for name,code in demos.items():
            def load_demo(c=code):
                self.text.delete("1.0",tk.END)
                self.text.insert("1.0",c)
                self.current_file = None
                popup.destroy()
                self.update_lines()
            tk.Button(popup,text=name,command=load_demo,bg="#3c3c3c",fg="white").pack(fill="x",padx=20,pady=5)

# ---------- Start ----------
if __name__=="__main__":
    root = tk.Tk()
    editor = GluEditor(root)
    if len(sys.argv)>1:
        path = sys.argv[1]
        if os.path.exists(path):
            editor.current_file = path
            with open(path) as f: editor.text.insert("1.0",f.read())
    root.mainloop()

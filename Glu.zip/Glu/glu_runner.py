import sys
from glu_engine import GluEngine

if len(sys.argv)<2:
    print("No code file provided")
    sys.exit(1)

filename=sys.argv[1]
with open(filename) as f:
    code=f.read()

engine=GluEngine()
engine.load_file(code=code)
engine.run()

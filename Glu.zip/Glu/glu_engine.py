import os, pygame, random

class GluEngine:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((640,480))
        pygame.display.set_caption("Glu Game")
        self.clock = pygame.time.Clock()
        self.objects = []
        self.stepSize = 32
        self.textures_path = "textures"
        if not os.path.exists(self.textures_path): os.makedirs(self.textures_path)

    def load_file(self, filename=None, code=None):
        if filename:
            with open(filename) as f:
                code = f.read()
        if code:
            for line in code.strip().splitlines():
                self.execute_line(line)

    def execute_line(self, line):
        line = line.strip()
        if line.startswith("--") or not line: return
        if line.startswith("createObject"):
            parts = line[line.find("(")+1:line.find(")")].split(",")
            obj = {"name": parts[0].strip('" ')}
            for part in parts[1:]:
                key,val = part.split("=")
                obj[key.strip()] = val.strip('" ')
            self.objects.append(obj)
        elif line.startswith("stepSize"):
            self.stepSize = int(line.split("=")[1].strip())

    def run(self):
        snake_mode = any(obj['name']=='snake' for obj in self.objects)
        pong_mode = any(obj['name']=='ball' for obj in self.objects) and any(obj['name'] in ['paddle1','paddle2'] for obj in self.objects)
        moving_square_mode = any(obj['name']=='square' for obj in self.objects)
        chaser_mode = any(obj['name']=='chaser' for obj in self.objects)

        if snake_mode: self.run_snake()
        elif pong_mode: self.run_pong()
        elif moving_square_mode: self.run_moving_square()
        elif chaser_mode: self.run_chaser()
        else: self.run_static()

    # ---------- Static renderer ----------
    def run_static(self):
        running = True
        while running:
            self.screen.fill((30,30,30))
            for event in pygame.event.get():
                if event.type == pygame.QUIT: running=False
            for obj in self.objects: self.draw_object(obj)
            pygame.display.flip()
            self.clock.tick(30)
        pygame.quit()

    # ---------- Snake ----------
    def run_snake(self):
        snake = [(5,5)]
        direction = (1,0)
        apple = (random.randint(0,19), random.randint(0,14))
        score = 0
        running = True

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT: running=False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_w and direction!=(0,1): direction=(0,-1)
                    elif event.key == pygame.K_s and direction!=(0,-1): direction=(0,1)
                    elif event.key == pygame.K_a and direction!=(1,0): direction=(-1,0)
                    elif event.key == pygame.K_d and direction!=(-1,0): direction=(1,0)

            head = (snake[0][0]+direction[0], snake[0][1]+direction[1])

            # Check collision with walls
            if head[0]<0 or head[0]>19 or head[1]<0 or head[1]>14:
                running=False
            # Check collision with itself
            if head in snake:
                running=False

            snake.insert(0,head)
            if head==apple:
                score += 1
                apple = (random.randint(0,19), random.randint(0,14))
            else:
                snake.pop()

            # Draw
            self.screen.fill((30,30,30))
            for seg in snake: pygame.draw.rect(self.screen,(0,200,0),(seg[0]*self.stepSize,seg[1]*self.stepSize,self.stepSize,self.stepSize))
            pygame.draw.rect(self.screen,(200,0,0),(apple[0]*self.stepSize,apple[1]*self.stepSize,self.stepSize,self.stepSize))
            # Score
            font = pygame.font.SysFont(None,24)
            text = font.render(f"Score: {score}",True,(255,255,255))
            self.screen.blit(text,(10,10))
            pygame.display.flip()
            self.clock.tick(5)
        pygame.quit()

    # ---------- Pong ----------
    def run_pong(self):
        ball=[10,5]
        ball_dir=[1,1]
        paddle1=5
        paddle2=5
        running=True
        while running:
            for event in pygame.event.get():
                if event.type==pygame.QUIT: running=False
            keys=pygame.key.get_pressed()
            if keys[pygame.K_w]: paddle1-=1
            if keys[pygame.K_s]: paddle1+=1
            if keys[pygame.K_UP]: paddle2-=1
            if keys[pygame.K_DOWN]: paddle2+=1
            ball[0]+=ball_dir[0]
            ball[1]+=ball_dir[1]
            if ball[1]<0 or ball[1]>14: ball_dir[1]*=-1
            if ball[0]<1 or ball[0]>19: ball_dir[0]*=-1
            self.screen.fill((30,30,30))
            pygame.draw.rect(self.screen,(200,0,0),(ball[0]*self.stepSize,ball[1]*self.stepSize,self.stepSize,self.stepSize))
            pygame.draw.rect(self.screen,(0,0,200),(1*self.stepSize,paddle1*self.stepSize,self.stepSize,3*self.stepSize))
            pygame.draw.rect(self.screen,(0,0,200),(18*self.stepSize,paddle2*self.stepSize,self.stepSize,3*self.stepSize))
            pygame.display.flip()
            self.clock.tick(10)
        pygame.quit()

    # ---------- Moving Square Demo ----------
    def run_moving_square(self):
        square = [5,5]
        running = True
        while running:
            for event in pygame.event.get():
                if event.type==pygame.QUIT: running=False
            keys=pygame.key.get_pressed()
            if keys[pygame.K_w]: square[1]-=1
            if keys[pygame.K_s]: square[1]+=1
            if keys[pygame.K_a]: square[0]-=1
            if keys[pygame.K_d]: square[0]+=1
            self.screen.fill((30,30,30))
            pygame.draw.rect(self.screen,(255,255,0),(square[0]*self.stepSize,square[1]*self.stepSize,self.stepSize,self.stepSize))
            pygame.display.flip()
            self.clock.tick(10)
        pygame.quit()

    # ---------- Chaser Demo ----------
    def run_chaser(self):
        player = [5,5]
        chaser = [15,10]
        running=True
        while running:
            for event in pygame.event.get():
                if event.type==pygame.QUIT: running=False
            keys=pygame.key.get_pressed()
            if keys[pygame.K_w]: player[1]-=1
            if keys[pygame.K_s]: player[1]+=1
            if keys[pygame.K_a]: player[0]-=1
            if keys[pygame.K_d]: player[0]+=1

            # Simple chase logic
            if chaser[0]<player[0]: chaser[0]+=1
            elif chaser[0]>player[0]: chaser[0]-=1
            if chaser[1]<player[1]: chaser[1]+=1
            elif chaser[1]>player[1]: chaser[1]-=1

            self.screen.fill((30,30,30))
            pygame.draw.rect(self.screen,(0,255,0),(player[0]*self.stepSize,player[1]*self.stepSize,self.stepSize,self.stepSize))
            pygame.draw.rect(self.screen,(255,0,0),(chaser[0]*self.stepSize,chaser[1]*self.stepSize,self.stepSize,self.stepSize))
            pygame.display.flip()
            self.clock.tick(5)
        pygame.quit()

    def draw_object(self,obj):
        texture_file=obj.get("texture")
        if texture_file:
            path=os.path.join(self.textures_path,texture_file)
            if os.path.exists(path):
                img=pygame.image.load(path)
                x=int(obj.get("x",0))*self.stepSize
                y=int(obj.get("y",0))*self.stepSize
                self.screen.blit(img,(x,y))
